package com.ams.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ams.dao.AllotedHangerDao;
import com.ams.dao.HangerDao;
import com.ams.dao.PlaneDao;
import com.ams.dao.UserDao;
import com.ams.model.AllotedHanger;
import com.ams.model.Hanger;
import com.ams.model.Plane;
import com.ams.model.User;

@Controller
public class HangerController {

	@Autowired
	private HangerDao hangerDao;

	@Autowired
	private AllotedHangerDao allotedHangerDao;

	@Autowired
	private PlaneDao planeDao;

	@Autowired
	private UserDao userDao;

	@GetMapping("/addhanger")
	public String addHanger() {
		return "addhanger";
	}

	@PostMapping("/addhanger")
	public ModelAndView addPilot(@ModelAttribute Hanger hanger) {
		ModelAndView mv = new ModelAndView();

		if (hanger.getManagerId() == 0) {
			mv.addObject("status", "Select Manager to add hanger!!!");
			mv.setViewName("index");
		}

		else {

			Hanger addHanger = this.hangerDao.save(hanger);

			if (addHanger != null) {

				User manager = this.userDao.findById(hanger.getManagerId()).get();

				manager.setHangerId(addHanger.getId());

				userDao.save(manager);

				mv.addObject("status", "Hanger Successfully Added!");
				mv.setViewName("index");
			}

			else {
				mv.addObject("status", "Failed to add Hanger!");
				mv.setViewName("index");

			}
		}

		return mv;
	}

	@GetMapping("/viewhanger")
	public ModelAndView viewhanger() {
		ModelAndView mv = new ModelAndView();

		List<Hanger> hangers = this.hangerDao.findAll();

		mv.addObject("hangers", hangers);
		mv.setViewName("viewhanger");

		return mv;
	}

	@GetMapping("/hangerstatus")
	public String hangerstatus() {
		return "hangerstatus";
	}

	@GetMapping("/hangerStatus")
	public ModelAndView hangerStatus(@RequestParam("hangerId") int hangerId, @RequestParam("date") String date) {
		ModelAndView mv = new ModelAndView();

		if (hangerId == 0) {
			mv.addObject("status", "Please select the Hanger for Status!!!");
			mv.setViewName("hangerstatus");

			return mv;
		}

		Hanger hang = this.hangerDao.findById(hangerId).get();

		List<AllotedHanger> allotedHangers = this.allotedHangerDao.findByHangerIdAndAllotedDate(hangerId, date);

		if (allotedHangers == null) {
			mv.addObject("status", "No Planes Alloted in Hanger on date " + date);
			mv.setViewName("hangerstatus");

			return mv;
		}

		List<Plane> planes = new ArrayList<>();

		for (AllotedHanger hanger : allotedHangers) {

			Plane plane = this.planeDao.findById(hanger.getPlaneId()).get();
			planes.add(plane);
		}

		int freeSpace = hang.getCapacity() - allotedHangers.size();

		if (freeSpace == 0) {
			mv.addObject("status", "No Space Left in Hanger on Date " + date);
		} else {
			mv.addObject("status", freeSpace + " Space Left in Hanger on Date " + date);
		}

		mv.addObject("planes", planes);
		mv.setViewName("hangerstatus");

		return mv;
	}

	@GetMapping("/allothanger")
	public String allothanger() {
		return "allothanger";
	}

	@GetMapping("/allotHanger")
	public ModelAndView allotHanger(@RequestParam("hangerId") int hangerId, @RequestParam("planeId") int planeId,
			@RequestParam("date") String date) {
		ModelAndView mv = new ModelAndView();

		if (hangerId == 0) {
			mv.addObject("status", "Please select the Hanger!!!");
			mv.setViewName("allothanger");

			return mv;
		}

		if (planeId == 0) {
			mv.addObject("status", "Please select the Plane!!!");
			mv.setViewName("allothanger");

			return mv;
		}

		Hanger hang = this.hangerDao.findById(hangerId).get();

		List<AllotedHanger> allotedHangers = new ArrayList<>();

		allotedHangers = this.allotedHangerDao.findByHangerIdAndAllotedDate(hangerId, date);

		int freeSpace = 0;

		if (allotedHangers != null && allotedHangers.size() != 0) {
			freeSpace = hang.getCapacity() - allotedHangers.size();
		}

		if (freeSpace == 0) {

			AllotedHanger allotedHanger = new AllotedHanger();
			allotedHanger.setHangerId(hangerId);
			allotedHanger.setPlaneId(planeId);
			allotedHanger.setAllotedDate(date);

			allotedHangerDao.save(allotedHanger);

			mv.addObject("status", "Plane Alloted Successful!!!");
			mv.setViewName("allothanger");

			return mv;

		} else {
			mv.addObject("status", "Can't Allot Hanger, No Space Left in Hanger on Date " + date);
			mv.setViewName("allothanger");

			return mv;
		}

	}

}
