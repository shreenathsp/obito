package com.ams.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ams.dao.PilotDao;
import com.ams.model.Pilot;
import com.ams.model.Plane;

@Controller
public class PilotController {

	@Autowired
	private PilotDao pilotDao;

	@GetMapping("/addpilot")
	public String addPilot() {
		return "addpilot";
	}

	@PostMapping("/addpilot")
	public ModelAndView addPilot(@ModelAttribute Pilot pilot) {
		ModelAndView mv = new ModelAndView();
		if (this.pilotDao.save(pilot) != null) {
			mv.addObject("status", "Pilot Successfully Added!");
			mv.setViewName("index");
		}

		else {
			mv.addObject("status", "Failed to add Pilot!");
			mv.setViewName("index");

		}

		return mv;
	}
	
	@GetMapping("/viewpilot")
	public ModelAndView viewPilot() {
		ModelAndView mv = new ModelAndView();

		List<Pilot> pilots = this.pilotDao.findAll();

		mv.addObject("pilots", pilots);
		mv.setViewName("viewpilot");

		return mv;
	}

}
