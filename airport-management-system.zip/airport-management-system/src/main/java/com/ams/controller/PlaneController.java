package com.ams.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ams.dao.PlaneDao;
import com.ams.model.Plane;

@Controller
public class PlaneController {

	@Autowired
	private PlaneDao planeDao;

	@GetMapping("/addplane")
	public String addPlane() {
		return "addplane";
	}

	@PostMapping("/addplane")
	public ModelAndView addPlane(@ModelAttribute Plane plane) {
		ModelAndView mv = new ModelAndView();
		if (this.planeDao.save(plane) != null) {
			mv.addObject("status", "Plane Successfully Added!");
			mv.setViewName("index");
		}

		else {
			mv.addObject("status", "Failed to add Plane!");
			mv.setViewName("index");

		}

		return mv;
	}

	@GetMapping("/viewplane")
	public ModelAndView viewPlane() {
		ModelAndView mv = new ModelAndView();

		List<Plane> planes = this.planeDao.findAll();

		mv.addObject("planes", planes);
		mv.setViewName("viewplane");

		return mv;
	}

}
