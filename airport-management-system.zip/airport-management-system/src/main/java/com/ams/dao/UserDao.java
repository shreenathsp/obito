package com.ams.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ams.model.User;

@Repository
public interface UserDao extends JpaRepository<User, Integer> {

	User findByEmailAddress(String emailId);

	User findByEmailAddressAndPassword(String emailAddress, String password);

	List<User> findByHangerId(int hangerId);

}
