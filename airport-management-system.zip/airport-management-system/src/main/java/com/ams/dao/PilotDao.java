package com.ams.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ams.model.Pilot;

@Repository
public interface PilotDao extends JpaRepository<Pilot, Integer>{

}
