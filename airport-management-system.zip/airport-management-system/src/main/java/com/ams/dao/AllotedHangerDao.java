package com.ams.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ams.model.AllotedHanger;

@Repository
public interface AllotedHangerDao extends JpaRepository<AllotedHanger, Integer> {

	List<AllotedHanger> findByHangerIdAndAllotedDate(int hangerId, String allotedDate);

	List<AllotedHanger> findByPlaneId(int planeId);

}
