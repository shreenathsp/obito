package com.ams.utility;

public class Constants {

	public enum TicketStatus {
		PENDING("Pending"),
		ASSIGNED_TO_TEAM("Assigned to Team"),
		RESOLVED("Resolved");
		
		private String status;

	    private TicketStatus(String status) {
	      this.status = status;
	    }

	    public String value() {
	      return this.status;
	    }
	     
	}
	
}
